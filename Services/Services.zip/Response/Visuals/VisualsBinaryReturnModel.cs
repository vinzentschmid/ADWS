﻿namespace DataCollector.ReturnModels.Visuals
{
    public class VisualsBinaryReturnModel : VisualsReturnModel
    {

        public String FinalText { get; set; }
    }
}
