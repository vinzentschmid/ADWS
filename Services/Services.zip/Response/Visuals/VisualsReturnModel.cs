﻿using Newtonsoft.Json;
using NJsonSchema.Converters;
using System.Runtime.Serialization;

namespace DataCollector.ReturnModels.Visuals
{


    [KnownType(typeof(VisualsNumericReturnModel))]
    [KnownType(typeof(VisualsBinaryReturnModel))]
    [JsonConverter(typeof(JsonInheritanceConverter), "discriminator")]
    public abstract class VisualsReturnModel
    {
        public String Icon { get; set; }
    }


}
