﻿namespace Services.Response.Basis
{
    public class ItemResultModel : ResponseModel
    {
        public Boolean Success { get; set; }
    }
}
