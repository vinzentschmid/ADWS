﻿namespace Services.Response.Basis
{
    public class ActionResultResponseModel : ResponseModel
    {

        public bool Success { get; set; }
    }
}
