﻿using Context.DAL;
using DAL.Influx;

namespace DataCollector.ReturnModels
{
    public class ValueReturnModelMultiple : ValueReturnModelBase
    {
        public List<Sample> Samples { get; set; } = new();
    }
}
