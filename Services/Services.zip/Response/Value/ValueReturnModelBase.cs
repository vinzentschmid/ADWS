﻿using Context.DAL.Visuals;
using DAL.MongoDB.Entities;

namespace DataCollector.ReturnModels
{
    public class ValueReturnModelBase
    {
        public DataPoint DataPoint { get; set; }


    }
}
